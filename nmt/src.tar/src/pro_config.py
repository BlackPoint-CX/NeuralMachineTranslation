import os

PROJECT_DIR = '/Users/alfredchen/PycharmProjects/NeuralMachineTranslation/nmt/'
DATA_DIR = os.path.join(PROJECT_DIR,'data')
